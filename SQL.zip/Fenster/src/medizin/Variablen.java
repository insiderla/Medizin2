package medizin;

public class Variablen {
	
	public static String [] VDaten = new String [5]; //1.Adresse , 2.Port , 3.Datenbankname, 4.Benutzer , 5.Passwort
	public static String Vergleichdaten[] = new String[100];
	public static String [][] Verkn = new String [50][5];
	public static String [] Primärschlüssel = new String [2];
	public static String Pfad =""; //Speicherpfad
	
	public static int anzahl_Tabellen = 0;
}
