package medizin;



public class main {

	public static void main(String[] args) {
		//Programm.laden();
		medizin.Programm.start();
		
	}

}
