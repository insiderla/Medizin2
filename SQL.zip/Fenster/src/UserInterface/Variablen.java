package UserInterface;

import org.eclipse.swt.widgets.Text;

public class Variablen {
	
	public static Text txt_DBServer;
	public static Text txt_DBPort;
	public static Text txt_DBName;
	public static Text txt_DBBenutzer;
	public static Text txt_DBPasswort;
	public static Text txt_Datei;
	
	public static int Zaehler_Windows = 1;
	
	public static boolean laden_0, laden_1, laden_2, laden_3 = false;
	public static String [] []Spaltennamen = new String [50][3] ;

}
