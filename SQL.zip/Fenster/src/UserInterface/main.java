package UserInterface;


import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;


public class main {

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		Display display = Display.getDefault();
		Shell shell = new Shell();
		shell.setSize(800, 600);
		shell.setText("MySQL to ARX");
		
		Allgemein.open(shell);
		Datenbank.open(shell);
		Verknuepfungen.open(shell);
		Spalten.open(shell);
		Speicherort.open(shell);
		Datenbank.visible_true();
		
		
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

}
//SELECT COUNT(*) FROM Studenten JOIN hoeren JOIN Vorlesungen ON Studenten.MatrNr = hoeren.MatrNr AND hoeren.VorlNr = Vorlesungen.VorlNr
//SELECT COUNT(*) FROM Studenten                              ON Studenten.MatrNr = hoeren.MatrNr AND hoeren.VorlNr = Vorlesungen.VorlNr